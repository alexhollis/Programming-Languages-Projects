Input: n, the number of nodes in the full binary tree
Output: The resulting tree combinations, in the form "[Node (LeftSubTree) (RightSubTree), ...], NumberOfInternalNodes, NumberOfLeaves"

How To Run:

1. At a terminal (Linux) or command prompt (Windows) type "ghci path/to/tree.hs".
2. Once the module has successfully loaded, type "printPossibleBinaryTrees n" in the console
where "n" is the number of internal nodes specified by you I.E 1,2,3,4...